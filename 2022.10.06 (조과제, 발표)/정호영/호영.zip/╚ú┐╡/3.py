import cv2
import mediapipe as mp
import math
import numpy as np
cx, cy, w, h = 100, 100, 200, 200 # 행열, 너비와 높이
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_hands = mp.solutions.hands
colorR=(255,0,255)


cap = cv2.VideoCapture(0)
cap.set(3, 1280) # 너비 사이즈 조정
cap.set(4, 720) # 높이 사이즈 조정
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')

def cornerRect(img, bbox, l=30, t=5, rt=1,
               colorR=(255, 0, 255), colorC=(0, 255, 0)):
    x, y, w, h = bbox
    x1, y1 = x + w, y + h
    if rt != 0:
        cv2.rectangle(img, bbox, colorR, rt)
    # Top Left  x,y
    cv2.line(img, (x, y), (x + l, y), colorC, t)
    cv2.line(img, (x, y), (x, y + l), colorC, t)
    # Top Right  x1,y
    cv2.line(img, (x1, y), (x1 - l, y), colorC, t)
    cv2.line(img, (x1, y), (x1, y + l), colorC, t)
    # Bottom Left  x,y1
    cv2.line(img, (x, y1), (x + l, y1), colorC, t)
    cv2.line(img, (x, y1), (x, y1 - l), colorC, t)
    # Bottom Right  x1,y1
    cv2.line(img, (x1, y1), (x1 - l, y1), colorC, t)
    cv2.line(img, (x1, y1), (x1, y1 - l), colorC, t)

    return img
class DragRect(): #클래스 생성
    def __init__(self,posCenter, size=[200,200]): # 초기값 설정후 사각형의 행열 너비 높이를 설정
        self.posCenter = posCenter #사각형의 행열
        self.size = size # 사각형 너비,높이

    def update(self,hand_8): #검지를 찾고 업데이트 하기 위해 메서드 생성
        cx,cy= self.posCenter #밑에 if 문 오류 안나게 하기 위해 작성
        w, h = self.size

        # 검지&중지 손가락 끝이 사각형 영역에 있는 경우
        if cx - w // 2 < hand_8[0] < cx + w // 2 and \
                cy - h // 2 < hand_12[1] < cy + h // 2:  # hand_8[0] = 검지의 x 좌표 hand_12[1] = 중지의 y 좌표
            self.posCenter = hand_8 # 사각형의 행열은 검지의 좌표가 됨



rectlist = [] # 빈 리스트 생성
for x in range(5): # 사각형 5개를 그리기 위해 범위 5 생성
    rectlist.append(DragRect([x*250+150,150])) # x에 1~5가 들어와서 x값이 바뀌어서 사각형이 옆으로 나란히 표시됨

with mp_hands.Hands(
        model_complexity=0,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5) as hands:
    while cap.isOpened():
        success, image = cap.read()
        if not success:
            break
        # 얼굴 찾기
        faces = face_cascade.detectMultiScale(image, 1.3, 5)
        # 모자이크 처리함수
        def mosaic(src, ratio=0.03):
            small = cv2.resize(src, None, fx=ratio, fy=ratio, interpolation=cv2.INTER_NEAREST)
            return cv2.resize(small, src.shape[:2][::-1], interpolation=cv2.INTER_NEAREST)

        for face in faces:
            x = face[0]
            y = face[1]
            width = face[2]
            height = face[3]
            image[y - 20:y + height + 20, x - 20:x + width + 20] = mosaic(
                image[y - 20:y + height + 20, x - 20:x + width + 20])

        # 손
        # openCV 는 기본적으로 BGR의 형태로 변환하여 데이터를 가져옴. BGR 순서를 RGB형태로 바꿔줌
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image) # 손 탐지
        image.flags.writeable = False # 읽기 전용
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR) # 이미지를 다시 BGR형태로 바꿔줌 (안바꾸면 색상이 이상하게 나옴)

        if results.multi_hand_landmarks: # 탐지한 손의 좌표가 있다면
            for hand_landmarks in results.multi_hand_landmarks: #좌표 하나씩 꺼내 변수에 담음
                # 엄지 검지 좌표
                hand_8 = hand_landmarks.landmark[8]
                hand_12 = hand_landmarks.landmark[12]

                # 엄지 검지 실제 픽셀값 변환
                image_h, image_w, _ = image.shape
                hand_8 = (int(hand_8.x * image_w), int(hand_8.y * image_h))  # 이미지 내의 실제 좌표 & 인수로 변환
                hand_12 = (int(hand_12.x * image_w), int(hand_12.y * image_h))

                # 동그라미 그리기
                cv2.circle(image, hand_8, 20, (255, 0, 0), 2, cv2.LINE_AA)  # 파란색
                cv2.circle(image, hand_12, 20, (0, 0, 255), 2, cv2.LINE_AA)  # 빨강색

                # 손 주석 그리기
                mp_drawing.draw_landmarks(
                    image,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS,
                    mp_drawing_styles.get_default_hand_landmarks_style(),
                    mp_drawing_styles.get_default_hand_connections_style())


                # 검지 중지 거리 구하기
                l = math.dist(hand_8,hand_12)
                if l <35 : #검지와 중지의 거리가 35 미만이면
                    # 여기서 업데이트
                    for rect in rectlist: # 사각형을 하나씩 꺼냄
                        rect.update(hand_8) # 손가락이 어떤 사각형을 가리키는지 확인하는 작업
                        # (rectlist 에는 Dragrect가 들어가있고 update 함수가 있음)

        # # 네모 그리기 corner= 네모에 구석에 틀 만들기 매개변수 = image,행열높이,길이,두께
        # for rect in rectlist:
        #     cx, cy = rect.posCenter
        #     w, h = rect.size
        #     cv2 .rectangle(image, (cx-w//2,cy-h//2), (cx+w//2, cy+h//2), colorR, cv2.FILLED)
        #     cvzone.cornerRect(image,(cx-w//2,cy-h//2,w,h),20,rt=0)
        ## 투명한 네모 그리기
        imagenew = np.zeros_like(image,np.uint8) #image의 shape만큼 0으로 채움
        for rect in rectlist: # 위에서 만들어둔 사각형 리스트에서 하나씩 꺼냄
            cx, cy = rect.posCenter # 사각형의 행,열
            w, h = rect.size # 사각형의 너비와 높이
            cv2.rectangle(imagenew, (cx-w//2,cy-h//2), (cx+w//2, cy+h//2), colorR, cv2.FILLED) #시작점 x,y 종료점 x,y , 색상 , cv2.FILLED 옵션 사용
            #정수 부분의 수만 구하기위해 //연산
            cornerRect(imagenew,(cx-w//2,cy-h//2,w,h),20,rt=0)

        image2 = image.copy() # 이미지 복사
        alpha = 0.3 # 투명도
        mask = imagenew.astype(bool) #imagenew 를 자료형으로
        # print(mask.shape)
        image2[mask] = cv2.addWeighted(image, alpha, imagenew, 1 - alpha, 0)[mask]
        cv2.imshow('MediaPipe Hands', cv2.flip(image2, 1)) # 보기 편하기 위해 이미지를 좌우를 반전후 실행 ( 1 = 수평 0 = 수직 )
        if cv2.waitKey(5) == ord('q'): # q 키를 눌러 종료
            break

cap.release() # 캠 해제
cv2.destroyAllWindows() #모든 윈도우 창 제거
