import mediapipe
import cv2
from cvzone.HandTrackingModule import HandDetector #손을 감지하는 모듈
# https://youtu.be/6DxN8G9vB50
cap = cv2.VideoCapture(0)
cap.set(3, 1280) # 너비 사이즈 조정
cap.set(4, 720) # 높이 사이즈 조정
detector = HandDetector() # 정확도가 0.8 이상일때 detector에 들어감
colorR = (255,0,255)
cx, cy, w, h = 100, 100, 200, 200 # 행열, 너비와 높이

while True:  #무한 반복문
    success, img = cap.read() # 비디오의 한 프레임씩 읽음
    img = cv2.flip(img, 1)  # 보기 편하게 뒤집음 1=수평 0=수직
    img = detector.findHands(img) # 비디오의 프레임에서 손을 찾음
    Lmlist, _ = detector.findPosition(img) # 손가락 좌표를 찾고 모든 좌표를 리스트에 담음

    if Lmlist: # 손가락이 있는 경우에
        l,_,_ = detector.findDistance(8,12,img) # 검지의 끝과 중지의 끝 사이의 거리
        # print(l)  중지와 검지가 닿았을때,떨어져있을때 좌표를 확인
        if l<30:  # l 이 30보다 작으면 클릭 = 직사각형 안에서 검지 중지가 서로 닿으면 직사각형이 클릭됨
            cursor = Lmlist[8]       # 검지의 X.Y 를 변수(cursor) 에 담음
            if cx-w//2<cursor[0]<cx+w//2 and \
                    cy-h//2<cursor[1]<cy+h//2: # 검지가 cx,cy 사이에 있다면 (cursor[0] = x [1] = y)
                colorR = 0,255,0 # 직사각형 범위 안에 검지가 들어오면 색이 바뀜
                cx, cy = cursor 
            else:
                colorR = (255, 0, 255) # 직사각형 범위 안에 검지가 안들어오면 원래 색으로 돌아감
   cv2.rectangle(img, (cx-w//2,cy-h//2) , (cx+w//2, cy+h//2), colorR, cv2.FILLED)
    # (직사각형 그리기 크기,색상)손가락 검지 중심 부분에 맞추기 위해 //2로 나눔
    cv2.imshow('Image',img) # 'Image' 이름으로 보여줌
    cv2.waitKey(1) # 키보드 입력을 대기하는 함수
cv2.destroyAllWindows()




