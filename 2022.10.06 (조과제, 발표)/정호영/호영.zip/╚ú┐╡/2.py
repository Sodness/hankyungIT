import cv2
import mediapipe as mp
import math
cx, cy, w, h = 100, 100, 200, 200 # 행열, 너비와 높이
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_hands = mp.solutions.hands
colorR=(255,0,255)

# For webcam input:
cap = cv2.VideoCapture(0)
cap.set(3, 1280) # 너비 사이즈 조정
cap.set(4, 720) # 높이 사이즈 조정
with mp_hands.Hands(
        model_complexity=0,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5) as hands:
    while cap.isOpened():
        success, image = cap.read()
        if not success:
            print("Ignoring empty camera frame.")
            # If loading a video, use 'break' instead of 'continue'.
            break

        # To improve performance, optionally mark the image as not writeable to
        # pass by reference.
        image.flags.writeable = False
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image)

        # Draw the hand annotations on the image.
        image.flags.writeable = True
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                # keypoints=detection.location_data.relative_keypoints
                # 엄지 검지 좌표

                hand_8 = hand_landmarks.landmark[8]

                hand_12 = hand_landmarks.landmark[12]

                # 엄지 검지 실제 픽셀값 변환
                image_h, image_w, _ = image.shape
                hand_8 = (int(hand_8.x * image_w), int(hand_8.y * image_h))  # 이미지 내의 실제 좌표 & 인수로 변환
                hand_12 = (int(hand_12.x * image_w), int(hand_12.y * image_h))

                # 동그라미 그리기
                cv2.circle(image, hand_8, 20, (255, 0, 0), 2, cv2.LINE_AA)  # 파란색
                cv2.circle(image, hand_12, 20, (0, 0, 255), 2, cv2.LINE_AA)  # 빨강색

                # 검지 중지 거리 구하기
                l = math.dist(hand_8,hand_12)
                if l <30:
                    if cx - w // 2 < hand_8[0] < cx + w // 2 and \
                            cy - h // 2 < hand_12[1] < cy + h // 2:  # 검지가 cx,cy 사이에 있다면 (cursor[0] = x [1] = y)
                        colorR = 0, 255, 0  # 직사각형 범위 안에 검지가 들어오면 색이 바뀜
                        cx, cy = hand_8  # 검지 x,y좌표를 cx cy로 나눠서 담음
                    else:
                        colorR = (255, 0, 255)  # 원래 색으로 돌아감
                mp_drawing.draw_landmarks(
                    image,
                    hand_landmarks,
                    mp_hands.HAND_CONNECTIONS,
                    mp_drawing_styles.get_default_hand_landmarks_style(),
                    mp_drawing_styles.get_default_hand_connections_style())

        # # 네모 그리기
        cv2.rectangle(image, (cx-w//2,cy-h//2), (cx+w//2, cy+h//2), colorR, cv2.FILLED)
        # Flip the image horizontally for a selfie-view display.
        cv2.imshow('MediaPipe Hands', cv2.flip(image, 1))
        if cv2.waitKey(5) == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
