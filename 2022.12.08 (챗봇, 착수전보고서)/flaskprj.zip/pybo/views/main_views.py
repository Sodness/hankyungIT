# url 생성
# route 기능 구현

# 주소를 쉽게 가져오고, 관리하는 Blueprint
from flask import Blueprint, render_template, request, jsonify
from pybo.models import Question

bp = Blueprint('main', __name__, url_prefix='/')

@bp.route('/')
def index():
    # print('Run')
    question_list = Question.query.order_by(Question.create_date.desc())
    return render_template('question/question_list.html', question_list=question_list, id='김영원')

@bp.route('/test')
def test():
    return render_template('test.html')

@bp.route('/test1')
def test1():
    return render_template('index.html')

@bp.route('/chatbot', methods=['POST'])
def chatbot():
    result = request.get_json()
    # print(result)
    print('영화 제목 : {}'.format(result['queryResult']['parameters']['movie_name']))
    # return render_template('chatbot.html')
    return {'fulfillmentText': '영화 내용을 알려줄까 말까?'}

@bp.route('/movie2')
def movie2():
    return render_template('movie2.html')

@bp.route('/movie1', methods=['POST'])
def movie1():
    result = request.get_json()
    # print(result)
    # print('영화 제목 : {}'.format(result['queryResult']['parameters']['movie_name']))
    # return render_template('chatbot.html')
    r = jsonify(
        fulfillment_text='포스터.',
        fulfillment_messages=[
            {
                "payload": {
                    "richContent": [
                        [
                            {
                                "type": "image",
                                "rawUrl": "https://w.namu.la/s/e4d8ce8f85cf0124f2d1e1dda636e568b352ec8369de9364f308b32ec2e92ed5af58206481b367dee2a45cc33b919459b4102589e12c12e7f29e8b48392ed144d4be601ce89de6376f3693c39d7dd272d6d7160e9f5c8507fd5e2e835e2b67860ce51957b02048dd50e1c2bf93c68585",
                                "accessibilityText": "Example logo"
                            }
                        ],
                        [
                            {
                                "type": "info",
                                "title": "Info item title",
                                "subtitle": "Info item subtitle",
                                "image": {
                                    "src": {
                                        "rawUrl": "https://example.com/images/logo.png"
                                    }
                                },
                                "actionLink": "https://www.naver.com"
                            }
                        ]
                    ]
                }
            }
        ]
    )
    return r






