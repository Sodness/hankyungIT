# 1장 KBO 타자 OPS 예측

* 실습에 필요한 패키지: [requirements.txt](requirements.txt)

* 예제 코드: [batter_OPS_prediction.ipynb](batter_OPS_prediction.ipynb)

* 데이터 다운로드: [https://dacon.io/competitions/official/62540/data/](https://dacon.io/competitions/official/62540/data/) (DACON 사이트 회원 가입 및 대회 참여 후 다운로드 가능)
