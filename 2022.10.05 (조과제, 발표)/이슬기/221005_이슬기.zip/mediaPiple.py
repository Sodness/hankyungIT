import cv2
import numpy as np
import keyboard
import time 
import mediapipe as mp
from sklearn import neighbors

max_num_hands=1
gesture = {
    0:'a',1:'b',2:'c',3:'d',4:'e',5:'f',6:'g',7:'h',
    8:'i',9:'j',10:'k',11:'l',12:'m',13:'n',14:'o',
    15:'p',16:'q',17:'r',18:'s',19:'t',20:'u',21:'v',
    22:'w',23:'x',24:'y',25:'z',26:'spacing',27:'clear',28:'delete'
}

# MediaPipe hands model 
mp_hands=mp.solutions.hands  
mp_drawing = mp.solutions.drawing_utils 

# 손가락 detection 모듈을 초기화 
hands=mp_hands.Hands(
    max_num_hands=max_num_hands, 
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# 제스처 인식 모델 
f=open('test.txt','w') # 학습시킬 dataset 저장하기 
file=np.genfromtxt('dataSet.txt',delimiter=',')
angle = file[:,:-1].astype(np.float32) # 각도
label = file[:, -1].astype(np.float32) # 라벨
knn=cv2.ml.KNearest_create() # knn(k-최근접 알고리즘)으로  
knn.train(angle,cv2.ml.ROW_SAMPLE,label) # 학습!

# 웹캠 열기 
cap=cv2.VideoCapture(0) 

# 웹캠에서 한 프레임씩 이미지를 읽어옴 
startTime = time.time()
prev_index = 0
sentence = ''
recognlzeDelay = 1
while True:
    ret,img = cap.read()
    if not ret:
        break
    img = cv2.flip(img, 1) 
    imgRGB = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    result = hands.process(imgRGB)

    # 각도를 인식하고 제스처를 인식하는 부분 
    if result.multi_hand_landmarks is not None:
        for res in result.multi_hand_landmarks:
            joint = np.zeros((21,3))
            
            for j,lm in enumerate(res.landmark):
                joint[j] = [lm.x,lm.y,lm.z]

            v1 = joint[[0,1,2,3,0,5,6,7,0,9,10,11,0,13,14,15,0,17,18,19],:] 
            v2 = joint[[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],:] 

            v = v2 - v1 # [20,3]관절벡터  
            v = v / np.linalg.norm(v, axis=1)[:, np.newaxis]

            compareV1 = v[[0,1,2,4,5,6,7,8,9,10,12,13,14,16,17],:]
            compareV2 = v[[1,2,3,5,6,7,9,10,11,13,14,15,17,18,19],:]
            angle = np.arccos(np.einsum('nt,nt->n',compareV1,compareV2))

            angle = np.degrees(angle)

            # a 누르면 저장하기 
            if keyboard.is_pressed('a'):
                for num in angle:
                    num = round(num,6)
                    f.write(str(num))
                    f.write(',')
                f.write('28.00000') # gesture에 들어갈 key 넣어주기 
                f.write('\n')
                print("next")
                print('---------------------')

            data = np.array([angle], dtype=np.float32)
            ret, result, neighbors,dist = knn.findNearest(data,3)
            index = int(result[0][0])

            cv2.putText(img, text=gesture[index].upper(), org=(int(res.landmark[0].x * img.shape[1]), int(res.landmark[0].y * img.shape[0] + 20)), fontFace=cv2.FONT_HERSHEY_SIMPLEX, fontScale=1, color=(255, 255, 255), thickness=2)

            if index in gesture.keys():
                if index != prev_index:
                    startTime = time.time()
                    prev_index = index
                else:
                    if time.time() - startTime > recognlzeDelay:
                        if index == 26: # spacing 
                            sentence += ' '
                        elif index == 27: # clear 
                            sentence = ''
                        elif index == 28: # delete 
                            sentence = sentence[:-1]
                        else:
                            sentence += gesture[index]
                        startTime = time.time()

            mp_drawing.draw_landmarks(img,res,mp_hands.HAND_CONNECTIONS)
    cv2.putText(img,sentence,(20,440),cv2.FONT_HERSHEY_SIMPLEX,2,(255,255,255),3)

    cv2.imshow('HandTracking',img)
    if cv2.waitKey(1) == ord('q'):
            break