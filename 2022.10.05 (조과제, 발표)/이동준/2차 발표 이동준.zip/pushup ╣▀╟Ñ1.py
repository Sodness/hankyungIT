from ctypes import resize
from unittest import result
import cv2
import mediapipe as mp
import math
import pandas as pd
import cvzone

#출처: https://youtu.be/sRqfQPlNa3M
# https://google.github.io/mediapipe/solutions/pose
cap = cv2.VideoCapture("pushup.mp4")

mpDraw = mp.solutions.drawing_utils
mpPose = mp.solutions.pose
pose = mpPose.Pose()
a=[] # 각도 담는 리스트
count = 0
position = None
while True:
    succes, img = cap.read()
    if not succes:
        break
    
    #높이 넓이 각도
    h, w, c = img.shape

    #색을 변환해 포즈 추정
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    result = pose.process(imgRGB)

    #포즈를 검출한다면
    if result.pose_landmarks:
        #mpDraw.draw_landmarks(img, result.pose_landmarks, mpPose.POSE_CONNECTIONS) #전체 랜드마크 표시

        p1 = result.pose_landmarks.landmark[11] #왼쪽 어깨
        p2 = result.pose_landmarks.landmark[13] #왼쪽 팔꿈치
        p3 = result.pose_landmarks.landmark[15] #왼쪽 손목
        p4 = result.pose_landmarks.landmark[23] #왼쪽 대관절
        p5 = result.pose_landmarks.landmark[25] #왼쪽 무릎
        p6 = result.pose_landmarks.landmark[27] #왼쪽 발목

        #실제 좌표
        x1 = int(p1.x*w) #왼쪽 어깨
        y1 = int(p1.y*h) #왼쪽 어깨

        x2 = int(p2.x*w) #왼쪽 팔꿈치
        y2 = int(p2.y*h) #왼쪽 팔꿈치

        x3 = int(p3.x*w) #왼쪽 손목
        y3 = int(p3.y*h) #왼쪽 손목

        x4 = int(p4.x*w) #왼쪽 대관절   
        y4 = int(p4.y*h) #왼쪽 대관절

        x5 = int(p5.x*w) #왼쪽 무릎
        y5 = int(p5.y*h) #왼쪽 무릎

        x6 = int(p6.x*w) #왼쪽 발목
        y6 = int(p6.y*h) #왼쪽 발목

        #선 그리기
        cv2.line(img, (x4, y4), (x5, y5), (255, 255, 255), 3)
        cv2.line(img, (x6, y6), (x5, y5), (255, 255, 255), 3)
        cv2.line(img, (x3, y3), (x2, y2), (255, 255, 255), 3) 
        cv2.line(img, (x1, y1), (x2, y2), (255, 255, 255), 3)

        #원 그리기
        cv2.circle(img, (x1, y1), 10, (255, 0, 0), 5)
        cv2.circle(img, (x2, y2), 10, (255, 0, 0), 5)
        cv2.circle(img, (x4, y4), 10, (255, 0, 0), 5)
        cv2.circle(img, (x5, y5), 10, (255, 0, 0), 5)
        cv2.circle(img, (x6, y6), 10, (255, 0, 0), 5)
        cv2.circle(img, (x3, y3), 10, (255, 0, 0), 5)

        
    cv2.imshow("Image", cv2.resize(img, (1280, 720)))
    

    if cv2. waitKey(5) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
df=pd.DataFrame(a)
df.to_csv('abc.csv')