from concurrent.futures import process
import tkinter
import cv2
import mediapipe as mp
import pyautogui
import time
import random
from cvzone.HandTrackingModule import HandDetector
import math
import numpy as np
import cvzone
from multiprocessing import Process
from threading import Thread

#출처: https://techceed-inc.com/engineer_blog/6921/
def mouse():
    mp_drawing = mp.solutions.drawing_utils
    mp_hands = mp.solutions.hands
    #화면 크기
    screen_width, screen_height = pyautogui.size()
    index_y=0
    # For webcam input:
    cap = cv2.VideoCapture(0)
    cap.set(3, 1280)
    cap.set(4, 720)
    with mp_hands.Hands(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5) as hands:
        while cap.isOpened():
            success, image1 = cap.read()
            if not success:
                print("Ignoring empty camera frame.")
                # If loading a video, use 'break' instead of 'continue'.
                continue
            # Flip the image horizontally for a later selfie-view display, and convert
            # the BGR image to RGB.
            image1 = cv2.cvtColor(cv2.flip(image1, 1), cv2.COLOR_BGR2RGB)
            # To improve performance, optionally mark the image as not writeable to
            # pass by reference.
            image1.flags.writeable = False
            results = hands.process(image1)

            # Draw the hand annotations on the image.
            image1.flags.writeable = True
            image1 = cv2.cvtColor(image1, cv2.COLOR_RGB2BGR)
            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        image1, 
                        hand_landmarks, 
                        mp_hands.HAND_CONNECTIONS)
                    #검지 끝의 좌표    
                    finger_tip_x=(hand_landmarks.landmark[8].x)
                    finger_tip_y=(hand_landmarks.landmark[8].y)
                    #검지 제2관절의 좌표
                    finger_pip_x=(hand_landmarks.landmark[6].x) 
                    finger_pip_y=(hand_landmarks.landmark[6].y)
                    #좌표값 수치로 변환
                    h, w, = image1.shape[1], image1.shape[0]
                    finger_tip_x=int(finger_tip_x*w) 
                    finger_tip_y=int(finger_tip_y*h)
                    finger_pip_x=int(finger_pip_x*w) 
                    finger_pip_y=int(finger_pip_y*h)
                    #검지를 구부렸을 때 클릭
                    if finger_tip_y > finger_pip_y: #검지 끝이 제2관절보다 클 때
                        finger_pip_x1 = int(screen_width/w * finger_pip_x)
                        finger_pip_y1 = int(screen_height/h * finger_pip_y)
                        pyautogui.click(finger_pip_x1, finger_pip_y1)
                        time.sleep(0.1)
                # # 위의 경우가 아닐 때는 커서를 항상 움직임
                    else:         
                        finger_pip_x1 = int(screen_width/w * finger_pip_x)
                        finger_pip_y1 = int(screen_height/h * finger_pip_y)
                        pyautogui.moveTo(finger_pip_x1, finger_pip_y1)
                cv2.imshow('MediaPipe Hands', image1)
                if cv2.waitKey(5) & 0xFF == ord('q'):
                    break
    cap.release()
    cv2.destroyAllWindows()

#출처:https://www.youtube.com/watch?v=NGQgRH2_kq8&t=2041s&ab_channel=Murtaza%27sWorkshop-RoboticsandAI
def game():

    # 카메라
    cap = cv2.VideoCapture(0)
    cap.set(3, 1280)
    cap.set(4, 720)

    # 손 찾기 
    detector = HandDetector(detectionCon=0.8, maxHands=1)

    # 펑션 찾기 
    # x는 거리의 값, y는 cm단위의 값 (예로 손을 20(y)에 두고 확인한 값이 300)
    #선형이 아니라 다항식 함수를 찾아야 함
    #곡선이 2차와 방향을 한번만 변경하는 곡선이므로 이차방정식 사용
    x = [300, 245, 200, 170, 145, 130, 112, 103, 93, 87, 80, 75, 70, 67, 62, 59, 57]
    y = [20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100]
    coff = np.polyfit(x, y, 2)  # y = Ax^2 + Bx + C 이차방정식

    # 원이 계속 변경되므로 게임 변수 설정
    cx, cy = 250, 250 # 원의 중심을 임의의 값으로 지정 
    color = (255, 0, 255)
    counter = 0
    score = 0
    timeStart = time.time()
    totalTime = 20

    # 루프
    while True:
        success, img = cap.read()
        img = cv2.flip(img, 1)

        if time.time()-timeStart < totalTime:

            hands = detector.findHands(img, draw=False)
            # 두 점 사이의 거리 구하기(피타고라스 정리)
            if hands:
                lmList = hands[0]['lmList']
                x, y, w, h = hands[0]['bbox']
                x1, y1, _ = lmList[5]
                x2, y2, _ = lmList[17]

                distance = int(math.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2)) # 루트와 거듭제곱 계산
                A, B, C = coff
                distanceCM = A * distance ** 2 + B * distance + C
                # print(distanceCM, distance)
                # 40cm보다 작으면 터치
                if distanceCM < 40:
                    if x < cx < x + w and y < cy < y + h:
                        cv2.putText(img, "+1" , (640, 360), cv2.FONT_HERSHEY_SIMPLEX, 5, (0,255,0), 5)
                        counter = 1
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 3)
                cvzone.putTextRect(img, f'{int(distanceCM)} cm', (x + 5, y - 10)) #부동값을 원치 않기에 거리 cm단위로 정수를 씀

            if counter:
                counter += 1
                color = (0, 255, 0)
                if counter == 3:
                    cx = random.randint(100, 1100)
                    cy = random.randint(100, 600)
                    color = (255, 0, 255)
                    score +=1
                    counter = 0

            # 버튼 그리기
            cv2.circle(img, (cx, cy), 30, color, cv2.FILLED)
            cv2.circle(img, (cx, cy), 10, (255, 255, 255), cv2.FILLED)
            cv2.circle(img, (cx, cy), 20, (255, 255, 255), 2)
            cv2.circle(img, (cx, cy), 30, (50, 50, 50), 2)

            # 게임 HUD
            cvzone.putTextRect(img, f'Time: {int(totalTime-(time.time()-timeStart))}',
                            (1000, 75), scale=3, offset=20)
            cvzone.putTextRect(img, f'Score: {str(score).zfill(2)}', (60, 75), scale=3, offset=20)
        else:
            cvzone.putTextRect(img, 'Game Over', (400, 400), scale=5, offset=30, thickness=7)
            cvzone.putTextRect(img, f'Your Score: {score}', (450, 500), scale=3, offset=20)
            cvzone.putTextRect(img, 'Press R to restart', (460, 575), scale=2, offset=10)



        cv2.imshow("Image", img)
        key = cv2.waitKey(1)
        
        if key == ord('r'):
            timeStart = time.time()
            score = 0
        if cv2.waitKey(5) & 0xFF == 27:
            break
    cap.release()
    cv2.destroyAllWindows()

# def chang():
#     win1 = tkinter.Tk()
#     btn1 = tkinter.Button(win1,
#     text = 'btn',
#     background = 'white')
#     btn1.config(width = 30, height= 5)
#     btn1.config(text = "게임 시작")
#     btn1.config(command = game)
#     btn1.pack()

#     win1.mainloop()

def button():
    # 버튼 제작
    win = tkinter.Tk()
    #win1 = tkinter.Tk()
    # 버튼 만들기 + 옵션 설정
    # btn = tkinter.Button(win,
    #     text = 'btn',
    #     background = 'white')
    # 버튼 옵션설정
    # btn.config(width = 30, height = 5)
    # btn.config(text = "button")
    # btn.config(command = mouse)
    # 두번째 버튼
    btn1 = tkinter.Button(win,
        width= 150, 
        height= 150,
        text = 'btn',
        background = 'white') 
    #btn1.config(width = 30, height = 5)
    btn1.config(text = "game start")
    btn1.config(command= game)

    # 버튼 배치하기
    # btn.pack()
    btn1.pack()

    win.mainloop()

# Thread 구현
if __name__ == '__main__':

    p1 = Thread(target=mouse).start()
    p2 = Thread(target=button).start()
    
    
    