# url 생성
# route 기능 구현

# 주소를 쉽게 가져오고, 관리하는 Blueprint
from flask import Blueprint, render_template, request
from pybo.models import Question

bp = Blueprint('main', __name__, url_prefix='/')

@bp.route('/')
def index():
    # print('Run')
    question_list = Question.query.order_by(Question.create_date.desc())
    return render_template('question/question_list.html', question_list=question_list, id='김영원')

@bp.route('/test')
def test():
    return render_template('test.html')

@bp.route('/test1')
def test1():
    return render_template('index.html')

@bp.route('/chatbot', methods=['POST'])
def chatbot():
    result = request.get_json()
    # print(result)
    print('영화 제목 : {}'.format(result['queryResult']['parameters']['movie_name']))
    # return render_template('chatbot.html')
    return {'fulfillmentText': '영화 내용을 알려줄까 말까?'}








