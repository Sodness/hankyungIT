# url 생성
# route 기능 구현

# 주소를 쉽게 가져오고, 관리하는 Blueprint
from flask import Blueprint
from pybo.models import Question
from datetime import datetime
from pybo import db

bp = Blueprint('news', __name__, url_prefix='/news')

@bp.route('/top')
def news_top():
    return 'top뉴스입니다.'

@bp.route('/week')
def news_week():
    return '주간뉴스입니다.'

@bp.route('/top/<int:newsno>')
def news_newsno(newsno):
    print(newsno)
    return 'top' + str(newsno) + '뉴스입니다.'

# @bp.route('/login/<id>/<pw>')
# def login(id, pw):
#     return 'ID : ' + id + ", PW : " + pw

# 이거 되네
@bp.route('/login/id=<id>&pw=<pw>')
def login(id, pw):
    return 'ID : ' + id + ", PW : " + pw

@bp.route('/insertqa')
def insertqa():
    for i in range(10):
        q = Question(subject='질문{}'.format(i), content='내용{}'.format(i), create_date=datetime.now())
        db.session.add(q)
    db.session.commit()
    return '데이터 입력 완료!!'

@bp.route('/get_qa_all')
def get_qa_all():
    result = Question().query.all()
    print(type(result)) # 리스트
    for tmp in result:
        print(str(tmp.id) + '\t' + tmp.subject + '\t' + tmp.content + '\t' + str(tmp.create_date))
    # return '데이터 불러오기 완료!'
    return '총 게시글 : {}개'.format(len(result))

@bp.route('/get_qa_pk/<int:pk>')
def get_qa_pk(pk):
    result = Question.query.get(pk)
    print(str(result.id) + '\t' + result.subject + '\t' + result.content + '\t' + str(result.create_date))
    return '가져오기 완료!'

@bp.route('/get_qa_title/<title>')
def get_qa_title(title):
    result = Question.query.filter(Question.subject == title).all()
    for tmp in result:
        print(str(tmp.id) + '\t' + tmp.subject + '\t' + tmp.content + '\t' + str(tmp.create_date))
    return '가져오기 완료!'




