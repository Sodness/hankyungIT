def hello():
  print('hello 함수 시작')
  print('hello')
  print('hello 함수 끝')

def world():
  print('world 함수 시작')
  print('world')
  print('world 함수 끝')

hello()
world()
