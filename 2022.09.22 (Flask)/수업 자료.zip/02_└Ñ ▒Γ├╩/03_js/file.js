function numbering(){
    i = 0;
    while(i < 5){
        document.write(i + "<br>");
        i += 1;
    }   
}
numbering();