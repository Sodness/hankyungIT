# url 생성
# route 기능 구현

# 주소를 쉽게 가져오고, 관리하는 Blueprint
from flask import Blueprint

bp = Blueprint('main', __name__, url_prefix='/')

@bp.route('/')
def hello_pybo():
    # print('Run')
    return 'Hello, Pybo!'















