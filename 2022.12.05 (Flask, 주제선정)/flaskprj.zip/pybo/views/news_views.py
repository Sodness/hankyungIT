# url 생성
# route 기능 구현

# 주소를 쉽게 가져오고, 관리하는 Blueprint
from flask import Blueprint

bp = Blueprint('news', __name__, url_prefix='/news')

@bp.route('/top')
def news_top():
    return 'top뉴스입니다.'

@bp.route('/week')
def news_week():
    return '주간뉴스입니다.'

@bp.route('/top/<int:newsno>')
def news_newsno(newsno):
    print(newsno)
    return 'top' + str(newsno) + '뉴스입니다.'

# @bp.route('/login/<id>/<pw>')
# def login(id, pw):
#     return 'ID : ' + id + ", PW : " + pw

# 이거 되네
@bp.route('/login/id=<id>&pw=<pw>')
def login(id, pw):
    return 'ID : ' + id + ", PW : " + pw






